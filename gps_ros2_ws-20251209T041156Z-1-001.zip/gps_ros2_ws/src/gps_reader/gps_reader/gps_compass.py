#!/usr/bin/env python3
# gps_compass.py — ROS 2 node: IMU -> heading (degrees) on /gps/heading

import math

import rclpy
from rclpy.node import Node
from sensor_msgs.msg import Imu
from std_msgs.msg import Float64
from tf_transformations import euler_from_quaternion


class GPSCompass(Node):
    def __init__(self):
        super().__init__("gps_compass")

        # Parameters
        self.declare_parameter("imu_topic", "/imu/data")
        self.declare_parameter("heading_topic", "/gps/heading")

        imu_topic = self.get_parameter("imu_topic").get_parameter_value().string_value
        heading_topic = (
            self.get_parameter("heading_topic").get_parameter_value().string_value
        )

        # Subscriber: IMU orientation
        self.create_subscription(Imu, imu_topic, self.imu_callback, 10)

        # Publisher: heading (degrees)
        self.heading_pub = self.create_publisher(Float64, heading_topic, 10)

        self.get_logger().info(
            f"gps_compass started: IMU topic = {imu_topic}, heading topic = {heading_topic}"
        )

    def imu_callback(self, msg: Imu):
        # Quaternion from IMU
        q = msg.orientation
        quat = [q.x, q.y, q.z, q.w]

        # Convert to roll, pitch, yaw
        roll, pitch, yaw = euler_from_quaternion(quat)

        # Yaw is in radians, convert to degrees and wrap to 0..360
        heading_deg = math.degrees(yaw)
        heading_deg = (heading_deg + 360.0) % 360.0

        # Publish heading
        h = Float64()
        h.data = heading_deg
        self.heading_pub.publish(h)

        self.get_logger().info(f"Heading: {heading_deg:.1f}°")


def main(args=None):
    rclpy.init(args=args)
    node = GPSCompass()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == "__main__":
    main()
